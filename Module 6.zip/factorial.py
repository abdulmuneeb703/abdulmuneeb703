#ABDUL MUNEEB SYED
#8/8/2022
#Problem 6: Use a for statement to calculate the factorial of a user input value. Print this value as well as the calculated value using the factorial function in the math module.

#Importing math
import math
#Take userinput
factorial= int(input("Enter the Factorial value?"))
#print factorial
print(math.factorial(factorial))