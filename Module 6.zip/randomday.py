#ABDUL MUNEEB SYED
#8/8/2022
#Problem 3: This program uses random.choice to select a day of the week from a list and print that day.

import random
#creating the list of weekdays
list = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
#printing the desired output
print(random.choice(list))
