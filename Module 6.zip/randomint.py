#ABDUL MUNEEB SYED
#8/8/2022

#This program uses a random.randrange to print an odd integer between 0 and 100.

#Importing the random
import random
for x in range(10):
    print(random.randrange(1,100,2))