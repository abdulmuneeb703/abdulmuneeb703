#ABDUL MUNEEB SYED
#8/8/2022

#This program uses a for statement and random.randrange to print 10 random integers between 25 and 35.

import random
for x in range(10):
    print(random.randrange(25,36))


