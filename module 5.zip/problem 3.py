#ABDUL MUNEEB SYED
#8/5/2022
#This program draws the expected polygon with the desired colors.
import turtle
SCREEN = turtle.Screen()
TURTLE = turtle.Turtle()
#This lines take the input from the users for sides and colors
sides= int(input("Number of sides? "))
length=int(input("Size of the length? "))
angle= 360/sides

TURTLE.color(input("color? "))
TURTLE.fillcolor(input("fill color?"))

TURTLE.begin_fill()
for i in range(sides):
    TURTLE.forward(length)
    TURTLE.left(angle)
TURTLE.end_fill()
#This exits the screen when the user clicks on it
SCREEN.exitonclick()