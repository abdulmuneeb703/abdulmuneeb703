#ABDUL MUNEEB SYED
#8/5/2022
#This program prints the objects in the lists x on a different line each
x = [12, 10, 32, 3, 66, 17, 42, 99, 20]
for i in x:
    print(i)
#This program prints the square of the objects in the lists x
for i in x:
    print(i, (i**2))
