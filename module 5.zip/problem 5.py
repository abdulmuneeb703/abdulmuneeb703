#ABDUL MUNEEB SYED
#8/5/2022
#This program draws a design using circles
import turtle

turtle.bgcolor('black')
turtle.speed(0)
turtle.pensize(2)
turtle.pencolor('red')

#This code executes the radius and range of circles
def drawcircle(radius):
    for i in range(10):
        turtle.circle(radius)
        radius= radius-4

def drawdesign():
    for i in range(10):
        drawcircle(120)
        turtle.right(36)

drawdesign()
turtle.exitonclick()
