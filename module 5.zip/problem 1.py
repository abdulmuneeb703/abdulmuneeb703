#ABDUL MUNEEB SYED
#8/5/2022
#This program prints Hello World 100 times.
for x in range(100):
    print("Hello World")
