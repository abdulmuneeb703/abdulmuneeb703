#ABDUL MUNEEB SYED
#8/5/2022
#This program prints out if the number is divisible by 3, 5 or both
for i in range( 1, 51):
    if i%15 ==0:
        print(i, " is Divisible by both")
    elif i%3 ==0:
        print(i," is Divisible by 3")
    elif i%5 ==0:
        print(i," is Divisible by 5")
    else:
        print(i)

