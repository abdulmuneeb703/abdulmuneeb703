#ABDUL MUNEEB SYED
#08/25/2022

#Defining a function to check whether they are qual to eachother or not
def problem1():
    Number1 = input("Enter a number ")
    Number2 = input("Enter the second number")
    if Number1 == Number2:
        print("They are equal ")
    else:
        print("They are not equal")

problem1()