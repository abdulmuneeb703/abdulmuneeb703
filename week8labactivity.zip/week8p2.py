# ABDUL MUNEEB SYED
# 08/25/2022

#Defining a function to check whether they are equal to 10, >10 and <10.
def problem2():
    Number1 = int(input("Enter a number "))
    Number2 = int(input("Enter the second number"))
    sum = Number1+Number2
    if sum == 10:
        print("The sum is equa1 to 10")
    elif sum>10:
        print("The sum is greater than 10")
    else:
        print("The sum is less than 10")

problem2()