#ABDUL MUNEEB SYED
#08/25/2022
#Defining a function to check whther the 5 is in the list or not
def problem3(list):
    if 5 in list:
        return "5 is in the list"
    else:
        return "5 is not in the list"



MyList = [1,2,3,4,5]
print(problem3(MyList))

#def add1(x):
#    return x + 1

#print(add1(5))
#if (add1(5) == 6):
#    print("5+1 is ", add1(5))