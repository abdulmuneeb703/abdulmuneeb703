# ABDUL MUNEEB SYED
# 08/25/2022

#a function that checks whether your game character has picked up all the items needed to perform certain tasks and checks against any status debuffs. Confirm checks with print statements
def problem5(status,items):
#Task 1: Climb a mountain – needs rope, coat, and first aid kit, cannot have slow
    print("Task 1 -- climb a mountain")
    if "rope" in items and "coat" in items and "first aid kit" in items:
        if "slow" not in status:
            print("You can climb a mountain")
        else:
            print("Cannot climb while slow")
    else:
        print("You do not have the gear to climb a mountain")

#Task 2: Cook a meal – needs pan, groceries, cannot have small
    print("Task 2 -- cook a meal")
    if  "pan" in items and "groceries" in items:
        if "small" not in status:
            print("You can cook")
        else:
            print("Cannot cook while small")
    else:
        print("You do not have proper items to cook")
    
#Task 3: Write a book – needs pen, paper, idea, cannot have confusion
    print("Task 3 -- write a book")
    if "pen" in items and "paper"in items and "idea" in items:
        if "confusion" not in status:
            print("You are ready to write a book")
        else:
            print("Cannot write while confused")
    else:
        print("You do not have the proper stationary")




status1 = ["slow"]
items1 = ["pan","groceries","idea","rope","paper"]
items2 = ["rope","coat","first aid kit"]
status2 = []
problem5(status1,items1)