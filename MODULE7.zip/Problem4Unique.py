#ABDUL MUNEEB SYED
#8/18/2022

list= [1, 3, 3, 3, 6, 2, 3, 5]
List=[]
def Unique(u):
    n=[]
    for i in u:
        if i not in n:
            n.append(i)

    return n
print(Unique(list))