#ABDUL MUNEEB SYED
#8/18/2022

def CheckRange(n):
    if n in range(1,10):
        print(n,"is in the range")
    else:
        print(n, "is not in the range")
CheckRange(11)