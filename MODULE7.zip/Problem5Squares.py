#ABDUL MUNEEB SYED
#8/18/2022

import turtle
def drawSquare(t,sz):
    for i in range (4):
        t.forward(sz)
        t.left(90)

wn = turtle.Screen()

alex = turtle.Turtle()
alex.color("red")
s=(10)
for i in range(6):
    s = s + 20
    drawSquare(alex,s)
    alex.penup()
    alex.right(135)
    alex.forward(15)
    alex.left(135)
    alex.pendown()

#drawSquare(alex,20)
#alex.right(135)
#alex.forward(15)
#alex.left(135)
#drawSquare(alex,40)
wn.exitonclick()
