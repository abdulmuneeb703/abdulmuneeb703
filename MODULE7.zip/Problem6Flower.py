#ABDUL MUNEEB SYED
#8/18/2022

import turtle
def drawHex(t,sz):
    for i in range (6):
        t.forward(sz)
        t.left(60)

wn = turtle.Screen()

alex = turtle.Turtle()
alex.color("magenta")
alex.pensize(3)
s=(10)
for i in range(10):
    drawHex(alex,50)
    alex.left(36)



wn.exitonclick()