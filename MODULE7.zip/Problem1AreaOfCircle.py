#ABDUL MUNEEB SYED
#8/18/2022
import math
def areaOfCircle(r):
    areaOfCircle= math.pi * r**2
    print(areaOfCircle)
areaOfCircle(2)